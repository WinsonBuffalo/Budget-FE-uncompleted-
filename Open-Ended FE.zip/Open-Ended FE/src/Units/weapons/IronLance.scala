package Units.weapons

class IronLance extends weapon {
  override val might: Int = 3
  override val range: Int = 1
  override val id: String = "Lance"
  override val goodAgainst: String = "Sword"
}
