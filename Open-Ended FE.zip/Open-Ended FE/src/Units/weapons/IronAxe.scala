package Units.weapons

class IronAxe extends weapon {
  override val might: Int = 3
  override val range: Int = 1
  override val id: String = "Axe"
  override val goodAgainst: String = "Lance"
}
