package Units.weapons

class Heal extends Staff {
  override val range: Int = 1
  override val might: Int = 10
}
