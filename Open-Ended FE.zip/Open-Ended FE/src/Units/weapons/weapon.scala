package Units.weapons

abstract class weapon extends EquipItem {
  val might: Int
  val range: Int
  val id: String
  val goodAgainst: String
}
