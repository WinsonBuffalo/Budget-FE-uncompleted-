package Units.weapons

class LegendSword extends weapon {
  override val might: Int = 9
  override val range: Int = 2
  override val id: String = "Sword"
  override val goodAgainst: String = "Axe"
}
