package Units.weapons

class SilverLance extends weapon {
  override val might: Int = 5
  override val range: Int = 1
  override val id: String = "Lance"
  override val goodAgainst: String = "Sword"
}
