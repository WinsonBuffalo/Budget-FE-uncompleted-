package Units.weapons

abstract class Staff extends EquipItem {
  override val might: Int
  override val range: Int
}
