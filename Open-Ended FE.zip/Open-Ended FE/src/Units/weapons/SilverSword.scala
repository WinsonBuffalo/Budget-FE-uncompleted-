package Units.weapons

class SilverSword extends weapon {
  override val might: Int = 5
  override val range: Int = 1
  override val id: String = "Sword"
  override val goodAgainst: String = "Axe"
}
