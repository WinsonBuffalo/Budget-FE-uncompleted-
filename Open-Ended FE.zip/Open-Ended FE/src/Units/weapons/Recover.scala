package Units.weapons

class Recover extends Staff {
  override val might: Int = 16
  override val range: Int = 2
}
