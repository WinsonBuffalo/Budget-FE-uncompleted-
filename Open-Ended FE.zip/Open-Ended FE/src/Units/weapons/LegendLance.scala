package Units.weapons

class LegendLance extends weapon {
  override val might: Int = 9
  override val range: Int = 2
  override val id: String = "Lance"
  override val goodAgainst: String = "Sword"
}
