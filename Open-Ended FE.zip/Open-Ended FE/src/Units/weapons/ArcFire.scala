package Units.weapons

class ArcFire extends weapon {
  override val might: Int = 5
  override val range: Int = 2
  override val id: String = "Magical"
  override val goodAgainst: String = null
}
