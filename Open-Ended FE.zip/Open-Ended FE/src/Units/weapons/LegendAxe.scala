package Units.weapons

class LegendAxe extends weapon {
  override val might: Int = 9
  override val range: Int = 2
  override val id: String = "Axe"
  override val goodAgainst: String = "Lance"
}
