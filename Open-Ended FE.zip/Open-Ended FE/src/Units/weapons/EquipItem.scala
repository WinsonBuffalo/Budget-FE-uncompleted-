package Units.weapons

abstract class EquipItem {
  val might: Int
  val range: Int
}
