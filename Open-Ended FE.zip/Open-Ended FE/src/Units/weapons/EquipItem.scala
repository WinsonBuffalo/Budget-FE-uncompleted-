package Units.weapons

abstract class EquipItem {
  val equipType: String
  val physical: Boolean
  val might: Int
  val range: Int
}
