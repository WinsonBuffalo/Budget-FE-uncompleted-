package Units

import Units.Items._
import Units.weapons.EquipItem

class Character(val HP: Int, var strength: Int, var magic: Int, var speed: Int, var defense: Int, var resist: Int, val move: Int, val equip: EquipItem, var phase: Boolean) {
  var currentHP: Int = HP
  var actionReady: Boolean = true
  var placementX: Int = 0
  var placementY: Int = 0
  var itemsList: List[item] = List()
  def mapPlacement(x: Int, y: Int): Unit ={
    placementX = x
    placementY = y
  }
  def attacked(enemy: Character, enemyRange: Int): Unit={

  }
  def HPLimit(addToHP: Int): Unit={
    currentHP+= addToHP
    if(currentHP > HP){
      currentHP = HP
    }
  }
  def useItem(listOfItems: List[item], select: item): Unit={
    if (listOfItems.contains(select)){
      if (select.stat == "HP"){
        this.HPLimit(select.addition)
      }
      if (select.stat == "strength"){
        strength += select.addition
      }
      if (select.stat == "magic"){
        magic += select.addition
      }
      if (select.stat == "speed"){
        speed += select.addition
      }
      if (select.stat == "defense"){
        defense += select.addition
      }
      if (select.stat == "resist"){
        resist += select.addition
      }
      actionReady = false
    }
  }

  def healed(plusToHP: Int): Unit={
    this.HPLimit(plusToHP)
  }
  def moveTo(x: Int, y: Int): Unit={
    val changeInX = (placementX - x).abs
    val changeInY = (placementY - y).abs
    if(changeInX + changeInY <= move){
      placementX = x
      placementY = y
    }
  }
  def tradeWith(trader: Character, traded: item): Unit={
    if (trader.phase == phase){
      trader.itemsList = trader.itemsList :+ traded
    }
  }
}
