package Units.Items

abstract class item {
  val stat: String
  val addition: Int
}
