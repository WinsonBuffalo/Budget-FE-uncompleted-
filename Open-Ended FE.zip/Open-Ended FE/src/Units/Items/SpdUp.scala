package Units.Items

class SpdUp extends item {
  override val stat: String = "speed"
  override val addition: Int = 2
}
