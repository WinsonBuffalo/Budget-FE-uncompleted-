package Units.Items

class potion extends item {
  override val stat: String = "HP"
  override val addition: Int = 15
}
