package Units.Items

class ResUp extends item {
  override val stat: String = "resist"
  override val addition: Int = 2
}
