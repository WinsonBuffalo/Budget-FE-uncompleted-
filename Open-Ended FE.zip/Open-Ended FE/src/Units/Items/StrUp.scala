package Units.Items

class StrUp extends item {
  override val stat: String = "strength"
  override val addition: Int = 3
}
