package Units.Items

class DefUp extends item {
  override val stat: String = "defense"
  override val addition: Int = 2
}
