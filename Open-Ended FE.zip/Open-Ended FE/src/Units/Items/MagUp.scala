package Units.Items

class MagUp extends item {
  override val stat: String = "magic"
  override val addition: Int = 3
}
