package MapLayout

class Location(val x: Int, val y: Int) {

}
