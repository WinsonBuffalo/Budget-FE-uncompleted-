package Turns

import MapLayout.Tile

abstract class Phase(gameState: GameState) {
  def moveUnit(unit: Units.Character, path: List[Tile]): Unit
  def attack(attacker: Units.Character, defender: Units.Character): Unit
  def useItem(user: Units.Character, item: Units.Items.item): Unit
  def heal(healer: Units.Character, target: Units.Character): Unit
}
