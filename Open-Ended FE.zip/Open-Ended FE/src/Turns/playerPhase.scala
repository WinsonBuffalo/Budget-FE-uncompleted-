package Turns

import MapLayout.Tile
import Units.Items.item

class playerPhase(gameState: GameState) extends Phase(gameState){
  override def moveUnit(unit: Units.Character, path: List[Tile]): Unit = {
    path = unit.
  }
  override def attack(attacker: Units.Character, defender: Units.Character): Unit = {

  }
  override def useItem(user: Units.Character, item: item): Unit = {

  }
  override def heal(healer: Units.Character, target: Units.Character): Unit = {

  }
}
